
const jwt = require("jsonwebtoken");

function autenticar(req, res, next) {
    const autorizacao = req.headers.authorization;

    if (!autorizacao) {
        return res.status(401).json({
            mensagem: "Acesso não autorizado."
        });
    }

    const token = autorizacao.split(" ")[1];

    try {
        const dados = jwt.verify(token, process.env.JWT_SECRET);

        req.usuario = dados;

        next();

    } catch (erro) {
        return res.status(401).json({
            mensagem: "Token inválido ou expirado."
        });
    }
}

module.exports = autenticar;
