
const router = require("express").Router();
const db = require("../config/db");
const auth = require("../middleware/auth");

router.get("/categorias", auth, async (req, res) => {
    try {
        const [categorias] = await db.execute(
            "SELECT * FROM categoria ORDER BY nome"
        );

        res.json(categorias);

    } catch (erro) {
        res.status(500).json({
            mensagem: "Erro ao buscar categorias."
        });
    }
});

module.exports = router;
