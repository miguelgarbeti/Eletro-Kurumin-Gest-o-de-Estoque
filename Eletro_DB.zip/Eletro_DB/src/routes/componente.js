
const router = require("express").Router();
const db = require("../config/db");
const auth = require("../middleware/auth");

router.use(auth);

// Listar
router.get("/componentes", async (req, res) => {
    try {
        const [dados] = await db.execute(`
            SELECT c.*, cat.nome AS categoria
            FROM componente c
            JOIN categoria cat
            ON c.id_categoria = cat.id_categoria
            ORDER BY c.nome
        `);

        res.json(dados);

    } catch (erro) {
        res.status(500).json({ mensagem: "Erro ao listar." });
    }
});

// Cadastrar
router.post("/componentes", async (req, res) => {
    try {
        const { id_categoria, nome, descricao, preco, quantidade_estoque } = req.body;

        if (!id_categoria || !nome || !Number.isFinite(preco) ||
            !Number.isInteger(quantidade_estoque) || preco < 0 ||
            quantidade_estoque < 0) {
            return res.status(400).json({ mensagem: "Dados inválidos." });
        }

        await db.execute(`
            INSERT INTO componente
            (id_categoria, id_usuario, nome, descricao, preco, quantidade_estoque)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [
            id_categoria,
            req.usuario.id,
            nome,
            descricao || null,
            preco,
            quantidade_estoque
        ]);

        res.status(201).json({ mensagem: "Componente cadastrado!" });

    } catch (erro) {
        res.status(500).json({ mensagem: "Erro ao cadastrar." });
    }
});

// Editar
router.put("/componentes/:id", async (req, res) => {
    try {
        const { id_categoria, nome, descricao, preco, quantidade_estoque } = req.body;

        if (!id_categoria || !nome || !Number.isFinite(preco) ||
            !Number.isInteger(quantidade_estoque) || preco < 0 ||
            quantidade_estoque < 0) {
            return res.status(400).json({ mensagem: "Dados inválidos." });
        }

        const [resultado] = await db.execute(`
            UPDATE componente
            SET id_categoria=?, nome=?, descricao=?, preco=?, quantidade_estoque=?
            WHERE id_componente=?
        `, [
            id_categoria, nome, descricao || null,
            preco, quantidade_estoque, req.params.id
        ]);

        if (!resultado.affectedRows) {
            return res.status(404).json({ mensagem: "Componente não encontrado." });
        }

        res.json({ mensagem: "Componente atualizado!" });

    } catch (erro) {
        res.status(500).json({ mensagem: "Erro ao editar." });
    }
});

// Excluir
router.delete("/componentes/:id", async (req, res) => {
    try {
        const [resultado] = await db.execute(
            "DELETE FROM componente WHERE id_componente=?",
            [req.params.id]
        );

        if (!resultado.affectedRows) {
            return res.status(404).json({ mensagem: "Componente não encontrado." });
        }

        res.json({ mensagem: "Componente excluído!" });

    } catch (erro) {
        if (erro.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(409).json({
                mensagem: "Este componente possui movimentações registradas."
            });
        }

        res.status(500).json({ mensagem: "Erro ao excluir." });
    }
});

// Relatório
router.get("/relatorios/estoque", async (req, res) => {
    try {
        const [dados] = await db.execute(`
            SELECT
                COUNT(*) AS total_componentes,
                COALESCE(SUM(quantidade_estoque), 0) AS total_unidades,
                COALESCE(SUM(preco * quantidade_estoque), 0) AS valor_total
            FROM componente
        `);

        res.json({ resumo: dados[0] });

    } catch (erro) {
        res.status(500).json({ mensagem: "Erro ao gerar relatório." });
    }
});

module.exports = router;
