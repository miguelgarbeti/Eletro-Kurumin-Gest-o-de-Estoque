
const router = require("express").Router();
const db = require("../config/db");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Cadastro
router.post("/usuarios", async (req, res) => {
    try {
        const { nome, email, senha } = req.body;

        if (!nome || !email || !senha) {
            return res.status(400).json({
                mensagem: "Preencha todos os campos."
            });
        }

        const senhaHash = await bcrypt.hash(senha, 10);

        await db.execute(
            "INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)",
            [nome, email, senhaHash]
        );

        res.status(201).json({
            mensagem: "Usuário cadastrado com sucesso!"
        });

    } catch (erro) {
        if (erro.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                mensagem: "Este e-mail já está cadastrado."
            });
        }

        res.status(500).json({
            mensagem: "Erro ao cadastrar usuário."
        });
    }
});

// Login
router.post("/auth", async (req, res) => {
    try {
        const { email, senha } = req.body;

        const [usuarios] = await db.execute(
            "SELECT * FROM usuario WHERE email = ?",
            [email]
        );

        if (usuarios.length === 0) {
            return res.status(401).json({
                mensagem: "E-mail ou senha incorretos."
            });
        }

        const usuario = usuarios[0];

        const senhaCorreta = await bcrypt.compare(
            senha,
            usuario.senha
        );

        if (!senhaCorreta) {
            return res.status(401).json({
                mensagem: "E-mail ou senha incorretos."
            });
        }

        const token = jwt.sign(
            {
                id: usuario.id_usuario,
                email: usuario.email
            },
            process.env.JWT_SECRET,
            { expiresIn: "2h" }
        );

        res.json({
            mensagem: "Login realizado!",
            token,
            nome: usuario.nome
        });

    } catch (erro) {
        res.status(500).json({
            mensagem: "Erro ao realizar login."
        });
    }
});

module.exports = router;
