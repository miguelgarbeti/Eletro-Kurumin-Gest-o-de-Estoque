
const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const usuarioRoutes = require("./src/routes/usuario");
const componenteRoutes = require("./src/routes/componente");
const categoriaRoutes = require("./src/routes/categoria");

const app = express();

app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, "public")));

app.use(usuarioRoutes);
app.use(componenteRoutes);
app.use(categoriaRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
