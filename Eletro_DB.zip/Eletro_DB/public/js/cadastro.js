
const API_URL = "http://localhost:3000";

const formulario = document.getElementById("cadastro-form");

formulario.addEventListener("submit", async function(evento) {

    evento.preventDefault();

    // Capturar os valores dos campos
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    const mensagem = document.getElementById("mensagem");

    try {

        // Enviar os dados para a API
        const resposta = await fetch(`${API_URL}/usuarios`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                nome: nome,
                email: email,
                senha: senha
            })

        });

        const dados = await resposta.json();

        if (resposta.ok) {

            mensagem.textContent = "Usuário cadastrado com sucesso!";

            formulario.reset();

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1500);

        } else {

            mensagem.textContent =
                dados.mensagem || "Erro ao cadastrar usuário.";

        }

    } catch (erro) {

        console.error("Erro:", erro);

        mensagem.textContent =
            "Não foi possível conectar ao servidor.";

    }

});
