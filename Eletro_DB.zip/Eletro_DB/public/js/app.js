
const API_URL = "http://localhost:3000";

const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "login.html";
}

const formulario = document.getElementById("componente-form");
const tabela = document.getElementById("tabela-componentes");

const mensagem = document.getElementById("mensagem");

const cabecalho = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${token}`
};

// Carregar categorias
async function carregarCategorias() {
    const resposta = await fetch(`${API_URL}/categorias`, {
        headers: cabecalho
    });

    const categorias = await resposta.json();

    const select = document.getElementById("comp-categoria");

    select.innerHTML = '<option value="">Selecione</option>';

    categorias.forEach(categoria => {
        select.innerHTML += `
            <option value="${categoria.id_categoria}">
                ${categoria.nome}
            </option>
        `;
    });
}

// Listar componentes
async function carregarComponentes() {
    const resposta = await fetch(`${API_URL}/componentes`, {
        headers: cabecalho
    });

    const componentes = await resposta.json();

    tabela.innerHTML = "";

    componentes.forEach(c => {
        tabela.innerHTML += `
            <tr>
                <td>${c.nome}</td>
                <td>${c.categoria}</td>
                <td>R$ ${Number(c.preco).toFixed(2)}</td>
                <td>${c.quantidade_estoque}</td>
                <td>
                    <button onclick="editarComponente(${c.id_componente})">
                        Editar
                    </button>

                    <button onclick="excluirComponente(${c.id_componente})">
                        Excluir
                    </button>
                </td>
            </tr>
        `;
    });

    if (componentes.length === 0) {
        tabela.innerHTML = `
            <tr>
                <td colspan="5">Nenhum componente cadastrado.</td>
            </tr>
        `;
    }
}

// Cadastrar ou editar
formulario.addEventListener("submit", async evento => {
    evento.preventDefault();

    const id = document.getElementById("id-componente").value;

    const componente = {
        id_categoria: Number(document.getElementById("comp-categoria").value),
        nome: document.getElementById("comp-nome").value,
        descricao: document.getElementById("comp-descricao").value,
        preco: Number(document.getElementById("comp-preco").value),
        quantidade_estoque: Number(document.getElementById("comp-quantidade").value)
    };

    try {
        const resposta = await fetch(
            id ? `${API_URL}/componentes/${id}` : `${API_URL}/componentes`,
            {
                method: id ? "PUT" : "POST",
                headers: cabecalho,
                body: JSON.stringify(componente)
            }
        );

        const dados = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = dados.mensagem || "Erro ao salvar.";
            return;
        }

        mensagem.textContent = dados.mensagem;

        formulario.reset();
        document.getElementById("id-componente").value = "";

        carregarComponentes();
        carregarRelatorio();

    } catch (erro) {
        mensagem.textContent = "Erro ao conectar com o servidor.";
    }
});

// Editar componente
async function editarComponente(id) {
    const resposta = await fetch(`${API_URL}/componentes`, {
        headers: cabecalho
    });

    const componentes = await resposta.json();

    const c = componentes.find(item => item.id_componente === id);

    if (!c) return;

    document.getElementById("id-componente").value = c.id_componente;
    document.getElementById("comp-nome").value = c.nome;
    document.getElementById("comp-categoria").value = c.id_categoria;
    document.getElementById("comp-descricao").value = c.descricao || "";
    document.getElementById("comp-preco").value = c.preco;
    document.getElementById("comp-quantidade").value = c.quantidade_estoque;

    document.getElementById("salvar-comp").textContent = "Salvar alterações";
    document.getElementById("cancelar-edicao").classList.remove("hidden");
}

// Excluir componente
async function excluirComponente(id) {
    if (!confirm("Deseja realmente excluir este componente?")) return;

    const resposta = await fetch(`${API_URL}/componentes/${id}`, {
        method: "DELETE",
        headers: cabecalho
    });

    const dados = await resposta.json();

    mensagem.textContent = dados.mensagem;

    carregarComponentes();
    carregarRelatorio();
}

// Cancelar edição
document.getElementById("cancelar-edicao").addEventListener("click", () => {
    formulario.reset();

    document.getElementById("id-componente").value = "";

    document.getElementById("salvar-comp").textContent = "Cadastrar Componente";

    document.getElementById("cancelar-edicao").classList.add("hidden");
});

// Relatório
async function carregarRelatorio() {
    const resposta = await fetch(`${API_URL}/relatorios/estoque`, {
        headers: cabecalho
    });

    const dados = await resposta.json();

    document.getElementById("total-componentes").textContent =
        dados.resumo.total_componentes;

    document.getElementById("total-unidades").textContent =
        dados.resumo.total_unidades;

    document.getElementById("valor-total").textContent =
        Number(dados.resumo.valor_total).toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
        });
}

// Sair
document.getElementById("sair").addEventListener("click", () => {
    localStorage.removeItem("token");
    localStorage.removeItem("usuario");

    window.location.href = "login.html";
});

// Inicialização
async function iniciarSistema() {
    try {
        await carregarCategorias();
        await carregarComponentes();
        await carregarRelatorio();
    } catch (erro) {
        mensagem.textContent = "Não foi possível carregar o sistema.";
        console.error(erro);
    }
}

iniciarSistema();
