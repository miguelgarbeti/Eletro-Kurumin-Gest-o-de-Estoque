
const API_URL = "http://localhost:3000";

const formulario = document.getElementById("login-form");

formulario.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
    const mensagem = document.getElementById("mensagem");

    try {
        const resposta = await fetch(`${API_URL}/auth`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, senha })
        });

        const dados = await resposta.json();

        if (resposta.ok) {
            localStorage.setItem("token", dados.token);
            localStorage.setItem("usuario", dados.nome);

            window.location.href = "index.html";
        } else {
            mensagem.textContent =
                dados.mensagem || "E-mail ou senha incorretos.";
        }

    } catch (erro) {
        mensagem.textContent = "Erro ao conectar com o servidor.";
        console.error(erro);
    }
});
